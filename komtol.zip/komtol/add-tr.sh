#!/bin/bash

NC='\033[0;37m' 
MYIP=$(curl -sS ipv4.icanhazip.com)
clear
source /var/lib/scrz-prem/ipvps.conf
if [[ "$IP" = "" ]]; then
domain=$(cat /etc/xray/domain)
else
domain=$IP
fi
#tr="$(cat ~/log-install.txt | grep -w "Trojan WS " | cut -d: -f2|sed 's/ //g')"
until [[ $user =~ ^[a-zA-Z0-9_]+$ && ${user_EXISTS} == '0' ]]; do
echo -e "\033[0;34m┌─────────────────────────────────────────────────┐\033[0m"
echo -e " \E[42;1;37m              CREATE TROJAN ACCOUNT              \E[0m"
echo -e "\033[0;34m└─────────────────────────────────────────────────┘\033[0m"

		read -rp "User: " -e user
		user_EXISTS=$(grep -w $user /etc/xray/config.json | wc -l)
		
		if [[ ${user_EXISTS} == '1' ]]; then
clear
		echo -e "\033[0;34m┌─────────────────────────────────────────────────┐\033[0m"
		echo -e " \E[42;1;37m               CREATE TROJAN ACCOUNT             \E[0m"
		echo -e "\033[0;34m└─────────────────────────────────────────────────┘\033[0m"
			echo ""
			echo "A client with the specified name was already created, please choose another name."
			echo ""
			echo -e "\033[0;34m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
			read -n 1 -s -r -p "Press any key to back on menu"
			menu-trojan
		fi
	done

uuid=$(cat /proc/sys/kernel/random/uuid)
read -p "Expired (days): " masaaktif
hariini=`date -d "0 days" +"%Y-%m-%d"`
exp=`date -d "$masaaktif days" +"%Y-%m-%d"`
sed -i '/#trojanws$/a\### '"$user $exp"'\
},{"password": "'""$uuid""'","email": "'""$user""'"' /etc/xray/config.json
sed -i '/#trojangrpc$/a\### '"$user $exp"'\
},{"password": "'""$uuid""'","email": "'""$user""'"' /etc/xray/config.json

systemctl restart xray
trojanlink="trojan://${uuid}@bug.com:443?path=%2Ftrojan-ws&security=tls&host=${domain}&type=ws&sni=${domain}#${user}"
trojanlink1="trojan://${uuid}@${domain}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni=bug.com#${user}"

mkdir -p /detail/trojan/
#Simpan Detail Akun User
cat > /detail/trojan/$user.txt <<-END

-----------------------------------------
BY ARYA NBC
wa.me/6281450330727
-----------------------------------------
Xray/Trojan Account
-----------------------------------------
Remarks          : ${user}
Host/IP          : ${domain}
User Ip          : 2 IP
Port             : 443,8443
Key              : ${uuid}
Path             : /trojan-ws
ServiceName      : trojan-grpc
-----------------------------------------
Link TLS         : ${trojanlink}
-----------------------------------------
Link GRPC        : ${trojanlink1}
-----------------------------------------
Aktif Selama     : $masaaktif Hari
Dibuat Pada      : $hariini
Berakhir Pada    : $exp
-----------------------------------------

END

cat >/var/www/html/trojan-$user.txt <<-END
-----------------------------------------
Format Open Clash
-----------------------------------------
- name: Trojan-$user-GO/WS
  server: ${domain}
  port: 443
  type: trojan
  password: ${uuid}
  network: ws
  sni: ${domain}
  skip-cert-verify: true
  udp: true
  ws-opts:
    path: /trojan-ws
    headers:
        Host: ${domain}

- name: Trojan-$user-gRPC
  type: trojan
  server: ${domain}
  port: 443
  password: ${uuid}
  udp: true
  sni: ${domain}
  skip-cert-verify: true
  network: grpc
  grpc-opts:
    grpc-service-name: trojan-grpc

-----------------------------------------
Link Akun Trojan 
-----------------------------------------
Link WS          : 
${trojanlink}
-----------------------------------------
Link GRPC        : 
${trojanlink1}
-----------------------------------------
Expired          : $exp
-----------------------------------------
END

CHATID="-1001911868043"
KEY="7876561487:AAHCpsZnu1LGx6w95fhqFMNSCT7fEGdv2vo"
export TIME="10"
export URL="https://api.telegram.org/bot$KEY/sendMessage"
sensor=$(echo "$user" | sed 's/\(.\{3\}\).*/\1xxx/')
ISP=$(curl -s ipinfo.io/org | cut -d " " -f 2-10 )
TEXT="
<b>-----------------------------------------</b>
<b>TRANSACTION SUCCESSFUL</b>
<b>-----------------------------------------</b>
<b>» Produk : Trojan</b>
<b>» ISP :</b> <code>${ISP}</code>
<b>» Limit Quota :</b> <code>${Quota} GB</code>
<b>» Limit Login :</b> <code>${iplimit} Hp</code>
<b>» Username :</b> <code>$sensor</code>
<b>» Duration :</b> <code>${masaaktif} Days</code>
<b>-----------------------------------------</b>
<i>Automatic Notification From Server</i>
<b>-----------------------------------------</b>"

clear
echo -e "\033[0;34m════════════\033[0;33mXRAY/TROJANWS\033[0;34m════════════${NC}"
echo -e "Remarks     : ${user}" 
echo -e "Created     : $hariini"
echo -e "Expired On  : $exp 👍"
echo -e "Host/IP     : ${domain}" 
echo -e "Port        : 443, 8443, 2087, 2096, 2053, 2083 "
echo -e "Key         : ${uuid}" 
echo -e "Path        : /trojan-ws"
echo -e "ServiceName : trojan-grpc" 
echo -e "\033[0;34m════════════════════════════════════${NC}"
echo -e "Link WS : "
echo -e "${trojanlink}" 
echo -e "\033[0;34m════════════════════════════════════${NC} "
echo -e "Link GRPC : "
echo -e "${trojanlink1}"
echo -e "\033[0;34m════════════════════════════════════${NC}" 
echo -e ""
echo -e " \033[0;32mSc By Arya Blitar${NC}" 
echo "" 
read -n 1 -s -r -p "Press any key to back on menu"

menu-trojan
